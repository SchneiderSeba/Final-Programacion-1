export const callsPending = [
    { "client": "Lucas Gómez", "number": 1144624234 },
    { "client": "Olivia Pérez", "number": 1143902699 },
    { "client": "Benjamín Romero", "number": 1147295254 },
    { "client": "Mateo García", "number": 1147577446 },
    { "client": "Mateo Pérez", "number": 1143153369 },
    { "client": "Santiago Gómez", "number": 1143533333 },
    { "client": "Olivia Pérez", "number": 1141521404 },
    { "client": "Lucas Pérez", "number": 1143798723 }
]